Example code.  Includes thrift clients and mapreduce uploader examples.
