This contrib contains transactional hbase (THBase) and indexed table hbase (ITHBase).
For how to use, include hbase-X.X.X-transactional.jar in your CLASSPATH and follow
the instruction in javadoc under the respective packages: org.apache.hadoop.hbase.client.transactional
and org.apache.hadoop.hbase.client.tableindexed.
