#set path=jre\bin
java -jar RJAR_0.8.jar _libs _libs com.apache.hadoop.hbase.tool.HBaseTool -Xmx512m